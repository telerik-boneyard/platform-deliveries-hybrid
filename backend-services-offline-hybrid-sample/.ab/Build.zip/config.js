
//WARNING: You must never include your master key in your app. We only use it
//in order to initialize the required server-side items for the demo to function.
Config = {
    ApiKey: 'bbiDJZxv87XRT4Vb',
    MasterKey: 'urBtvDmkXcaQRW8eD3U6GMKKrWROOmKd'
};